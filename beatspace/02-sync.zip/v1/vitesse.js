const player = document.querySelector('.player_audio');
const playerDisplay = document.querySelector('.player_display');

const changeTempo = function () {
  player.playbackRate = tempoInput.value;
  tempoDisplay.textContent = tempoInput.value;
};

// Playback tempo 
const tempoInput = document.getElementById('tempo_input');
tempoInput.addEventListener("change", changeTempo, false);
const tempoDisplay = document.querySelector('.tempo_display');
tempoDisplay.textContent = tempoInput.value;

player.src = "./../music/tempo1/yokota.mp3";
// changeSongURL();
changeTempo();